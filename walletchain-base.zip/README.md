# Sample Hardhat Project

This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a Hardhat Ignition module that deploys that contract.

Try running some of the following tasks:

```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat ignition deploy ./ignition/modules/Lock.js
```


walletchain-base : 에러랑 모두 잡은 버전. 로직은 손봐야 함. 

NEXT 
1. 로직 손보고 
2. 테스트 코드 작성하고 
3. 시나리오 입히고 

우선 여기까지.